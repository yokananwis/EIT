function A = bitmap_downsize(A, factor)
%BITMAP_DONWSIZE scale down an image (anti-aliasing)
% A = downsize(A, N) downsizes image array A by a factor N (natural number)
%
% This function is part of the EXPORT_FIG suite by Oliver Woodford
% http://www.mathworks.com/matlabcentral/fileexchange/23629

% Copyright (C) Oliver Woodford 2008-2012
% License: BSD, see accompanying license.txt
% $Id: bitmap_downsize.m 5522 2017-06-07 12:03:37Z aadler $

if factor == 1
    % Nothing to do
    return
end
try
    % Faster, but requires image processing toolbox
    A = imresize(A, 1/factor, 'bilinear');
catch
    % No image processing toolbox - resize manually
    % Lowpass filter - use Gaussian as is separable, so faster
    % Compute the 1d Gaussian filter
    filt = (-factor-1:factor+1) / (factor * 0.6);
    filt = exp(-filt .* filt);
    % Normalize the filter
    filt = single(filt / sum(filt));
    % Filter the image
    padding = floor(numel(filt) / 2);
    for a = 1:size(A, 3)
        A(:,:,a) = conv2(filt, filt', single(A([ones(1, padding) 1:end repmat(end, 1, padding)],[ones(1, padding) 1:end repmat(end, 1, padding)],a)), 'valid');
    end
    % Subsample
    A = A(1+floor(mod(end-1, factor)/2):factor:end,1+floor(mod(end-1, factor)/2):factor:end,:);
end
